</center>
<div class="div"><center><form class="uff" action="send.php" method="POST">

<div>Sendungsnummer:</div>

<input id="FSendungsnummer" name="FSendungsnummer" required="" type="number"> <br>

<div>Empfänger:</div>
<input id="FEmpfänger" name="FEmpfänger" required="" type="text"> <br>

<div>Status:</div>

<select id="Fsendungsstatus" name="Fsendungsstatus">
  <option value="Label Erstellt">Label Erstellt</option>
  <option value="An Paketdienstleister übergeben">An Paketdienstleister übergeben</option>
  <option value="In Zustellung">In Zustellung</option>
  <option value="Zugestellt">Zugestellt</option>
</select> <br>

<input type="submit" value="Abschicken" /></form></center></div>